/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidorhoroscopo;
import interfaz.irHoroscopo;
import java.rmi.RemoteException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author javier
 */
public class Horoscopo implements irHoroscopo{
    public Horoscopo(){
        super();
    }

    /**
     *
     * @param d
     * @param m
     * @return
     * @throws RemoteException
     */
    @Override
    public String CalculadoraHoroscopo(int d, int m) throws RemoteException {
       
    
      String cadena = null;
              String cadena1;

			
	  if(d>=20 && m==1){
	       	//Enero 20 – Febrero 18-> acuario
	       cadena="Su signo es acuario";
    	           }
		else if(d<=18 && m==2){
	        //Enero 20 – Febrero 18-> acuario
	        cadena="Su signo es acuario";
		}
		
		
		
		
		else if(d>=19 && m==2){
	     	//Febrero 19 – Marzo 20
	        cadena="Su signo es piscis";
    	}
	    
	    else if(d<=20 && m==3){
			//Febrero 19 – Marzo 20
	              cadena="Su signo es piscis";
		}
		
		
		
		else if(d>=21 && m==3){
		      //Marzo 21 –Abril 19
	            cadena="Su signo es aries";
      	}
	    else if(d<=19 && m==4){
		    	//Marzo 21 –Abril 19
	            cadena="Su signo es aries";
		}
	
	
	   		
		 else if(d>=20 && m==4){
	          //Abril 20 – Mayo 20-> tauro
	                  cadena="Su signo es tauro";
	    }
	    else if(d<=20 && m==5){
		        //Abril 20 – Mayo 20-> tauro
	                       cadena="Su signo es tauro";
		}
		
		
		else if(d>=21 && m==5){
	        		//Mayo 21 – Junio 20 -> geminis
	                         cadena="Su signo es geminis";
     	}
	    else if(d<=20 && m==6){
		        	//Mayo 21 – Junio 20 -> geminis
	                           cadena="Su signo es geminis";
		}


       	
		else if(d>=21 && m==6){
		        	//Junio 21 – Julio 22-> cancer
	                              cadena="Su signo es cancer";   
    	}	
    	else if(d<=22 && m==7){
		         	//Junio 21 – Julio 22-> cancer
	                        cadena="Su signo es cancer";  
		}
		
		
	     else if(d>=23 && m==7){
		            //Julio 23–Agosto 22-> leo
	                cadena="Su signo es leo"; 
    	}
	    else if(d<=22 && m==8){
	           		  //Julio 23–Agosto 22-> leo
	                    cadena="Su signo es leo"; 
		}
	
	
	  
		else if(d>=23 && m==8){
		       //Agosto 23 – Septiembre 22-> virgo
	                     cadena="Su signo es virgo";
    	}
    	else if(d<=22 && m==9){
			//Agosto 23 – Septiembre 22-> virgo
	                     cadena="Su signo es virgo";
		}
		
		
		
		
		else if(d>=23 && m==9){
		    //Septiembre 23 – Octubre 22-> libra
	               cadena="Su signo es libra";
	    }
	    else if(d<=22 && m==10){
		   //Septiembre 23 – Octubre 22-> libra
	                  cadena="Su signo es libra";
		}
	
	
		else if(d>=23 && m==10){
		    //Octubre 23 – Noviembre 21-> escorpion
	                   cadena="Su signo es escorpion";
	    }
	     else if(d<=21 && m==11){
		  //Octubre 23 – Noviembre 21-> escorpion
	               cadena="Su signo es escorpion";
		}
		
		
		else if(d>=22 && m==11){
		   	//Noviembre 22 - Diciembre 21-> sagitario
	                   cadena="Su signo es sagitario";
     	}
     	else if(d<=22 && m==12){
			//Noviembre 22 - Diciembre 21-> sagitario
	                      cadena="Su signo es sagitario";
		}
	   
	   
		else if(d>=20 && m==1){
		  //Enero 20 – Febrero 18-> acuario
	              cadena="Su signo es acuario";
	    }
	    else if(d<=18 && m==2){
			//Enero 20 – Febrero 18-> acuario
	                   cadena="Su signo es acuario";
		}
	
	
		else if(d>=22 && m==12){
		    //Diciembre 22 – Enero 19-> capricornio
	                    cadena="Su signo es capricornio";
	    }
	    else if(d<=19 && m==1){
			 //Diciembre 22 – Enero 19-> capricornio
	                    cadena="Su signo es capricornio";
		}
	
         cadena1=cadena;
	  return cadena;
        
    }
    
    
    
    //servicio numero 2
    @Override
    public String HoroscopoSemana(int signo) throws RemoteException {
         
       String resultado = null;  
       //Cadena de conexión de MySql, el parametro useSSL es opcional
        String url = "jdbc:mysql://localhost/horoscopo";
        // Cargamos el driver de mysql
        try {
              Class.forName("com.mysql.jdbc.Driver");
        // Creamos el objeto conexion
        Connection conexion = (Connection) DriverManager.getConnection(url, "root", "");
        // Creamos un objeto Statement
        Statement instruccion = conexion.createStatement();

        

// Creamos el switch
        switch(signo){
        
               case 1:
           //piscis
               String sql = "select nombre,color,personalidad,semanal from signo where id_signo=8";
               ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
            }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         break;
         
         
        case 2:
             //tauro
               String sql2 = "select nombre,color,personalidad,semanal from signo where id_signo=10";
               ResultSet result2 = instruccion.executeQuery(sql2);

            if(result2.next()){
               String a1=result2.getString(1);
               String a2=result2.getString(2);
               String a3=result2.getString(3);
               String a4=result2.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result2.close();
               instruccion.close();
               conexion.close();
            
        break;
        
        
        case 3:
             //geminis
               String sql3 = "select nombre,color,personalidad,semanal from signo where id_signo=11";
               ResultSet result3 = instruccion.executeQuery(sql3);

            if(result3.next()){
               String a1=result3.getString(1);
               String a2=result3.getString(2);
               String a3=result3.getString(3);
               String a4=result3.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result3.close();
               instruccion.close();
               conexion.close();
        break;
        
        case 4:
             //cancer
               String sql4 = "select nombre,color,personalidad,semanal from signo where id_signo=12";
               ResultSet result4 = instruccion.executeQuery(sql4);

            if(result4.next()){
               String a1=result4.getString(1);
               String a2=result4.getString(2);
               String a3=result4.getString(3);
               String a4=result4.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result4.close();
               instruccion.close();
               conexion.close();
        break;
        
        case 5:
             //leo
               String sql5 = "select nombre,color,personalidad,semanal from signo where id_signo=1";
               ResultSet result5 = instruccion.executeQuery(sql5);

            if(result5.next()){
               String a1=result5.getString(1);
               String a2=result5.getString(2);
               String a3=result5.getString(3);
               String a4=result5.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result5.close();
               instruccion.close();
               conexion.close();
        break;
        
        
        case 6:
             //libra
               String sql6 = "select nombre,color,personalidad,semanal from signo where id_signo=3";
               ResultSet result6 = instruccion.executeQuery(sql6);

            if(result6.next()){
               String a1=result6.getString(1);
               String a2=result6.getString(2);
               String a3=result6.getString(3);
               String a4=result6.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result6.close();
               instruccion.close();
               conexion.close();
        break;
        
        
        case 7:
             //escorpion
               String sql7 = "select nombre,color,personalidad,semanal from signo where id_signo=4";
               ResultSet result7 = instruccion.executeQuery(sql7);

            if(result7.next()){
               String a1=result7.getString(1);
               String a2=result7.getString(2);
               String a3=result7.getString(3);
               String a4=result7.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result7.close();
               instruccion.close();
               conexion.close();
        break;
        
        
        case 8:
             //sagitario
               String sql8 = "select nombre,color,personalidad,semanal from signo where id_signo=5";
               ResultSet result8 = instruccion.executeQuery(sql8);

            if(result8.next()){
               String a1=result8.getString(1);
               String a2=result8.getString(2);
               String a3=result8.getString(3);
               String a4=result8.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result8.close();
               instruccion.close();
               conexion.close();
        break;
        
        
        case 9:
             //carpicornio
               String sql9 = "select nombre,color,personalidad,semanal from signo where id_signo=6";
               ResultSet result9 = instruccion.executeQuery(sql9);

            if(result9.next()){
               String a1=result9.getString(1);
               String a2=result9.getString(2);
               String a3=result9.getString(3);
               String a4=result9.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result9.close();
               instruccion.close();
               conexion.close();
        break;
        
        
        case 10:
             //acuario
               String sql10 = "select nombre,color,personalidad,semanal from signo where id_signo=7";
               ResultSet result10 = instruccion.executeQuery(sql10);

            if(result10.next()){
               String a1=result10.getString(1);
               String a2=result10.getString(2);
               String a3=result10.getString(3);
               String a4=result10.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result10.close();
               instruccion.close();
               conexion.close();
        break;
        
        
        case 11:
             //aries
               String sql11 = "select nombre,color,personalidad,semanal from signo where id_signo=9";
               ResultSet result11 = instruccion.executeQuery(sql11);

            if(result11.next()){
               String a1=result11.getString(1);
               String a2=result11.getString(2);
               String a3=result11.getString(3);
               String a4=result11.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result11.close();
               instruccion.close();
               conexion.close();
        break;
        
        
         case 12:
             //virgo
               String sql12 = "select nombre,color,personalidad,semanal from signo where id_signo=2";
               ResultSet result12 = instruccion.executeQuery(sql12);

            if(result12.next()){
               String a1=result12.getString(1);
               String a2=result12.getString(2);
               String a3=result12.getString(3);
               String a4=result12.getString(4);
                resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n";
                               }

            // Cerrar cada uno de los objetos utilizados
               result12.close();
               instruccion.close();
               conexion.close();
        break;
        }

     
          }
           catch(ClassNotFoundException | SQLException e) {
           e.printStackTrace();
           }               
               return resultado;
    }
         
    //servicio numero 3
     @Override
    public String CompatibilidadHoroscopo(int signo1, int signo2) throws RemoteException {
        
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        String resultado = null;  
       //Cadena de conexión de MySql, el parametro useSSL es opcional
        String url = "jdbc:mysql://localhost/horoscopo"+ "?useSSL=false";
        // Cargamos el driver de mysql
        try{
              Class.forName("com.mysql.jdbc.Driver");
        // Creamos el objeto conexion
        Connection conexion = (Connection) DriverManager.getConnection(url, "root", "");
        // Creamos un objeto Statement
        Statement instruccion = conexion.createStatement();
        
        
        /********************************************/

        //Aries y Aries
        if(signo1==1 && signo2==1){
            
               String sql = "select elementos, analisis from comparativa where id_comp=1";
               ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               
               resultado="\nElementos:"+a1+"\nAnalisis:"+a2+"\n";
            }
        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
        }
     
        
    }
           catch(ClassNotFoundException | SQLException e) {
           e.printStackTrace();
           }
               return resultado;
    }

    
    //servicio 4

    /**
     *
     * @param d
     * @param m
     * @param a
     * @param genero
     * @return
     * @throws RemoteException
     */
    
    @Override
    public String HoroscopoChino(int d,int m,int a,int genero) throws RemoteException {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        String resultado = null;  
       //Cadena de conexión de MySql, el parametro useSSL es opcional
        String url = "jdbc:mysql://localhost/horoscopo";
        // Cargamos el driver de mysql
        try{
              Class.forName("com.mysql.jdbc.Driver");
        // Creamos el objeto conexion
        Connection conexion = (Connection) DriverManager.getConnection(url, "root", "");
        // Creamos un objeto Statement
        Statement instruccion = conexion.createStatement();
        
        
        /********************************************/
     if (a%12==0){
        //perro 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=12";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
         }
     else if(a%12==1){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=11";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==2){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=10";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==3){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=9";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==4){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=8";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==5){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=7";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     
     else if(a%12==6){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=6";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     
     else if(a%12==7){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=5";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==8){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=4";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==9){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=3";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else if(a%12==10){
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=2";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
     
     else{
           //cerdo 
        String sql = "select nombre,descripcion,planeta,elemento,hora_influencia,personalidad,signo_compatible from signo_chino where id=1";
        ResultSet result = instruccion.executeQuery(sql);

        if(result.next()){
               String a1=result.getString(1);
               String a2=result.getString(2);
               String a3=result.getString(3);
               String a4=result.getString(4);
               String a5=result.getString(5);
               String a6=result.getString(6);
               String a7=result.getString(7);
               resultado="\n"+a1+"\n"+a2+"\n"+a3+"\n"+a4+"\n"+a5+"\n"+a6+"\n"+a7;
        }

        // Cerrar cada uno de los objetos utilizados
               result.close();
               instruccion.close();
               conexion.close();
     }
        }
        catch(ClassNotFoundException | SQLException e) {
           e.printStackTrace();
           }
        return resultado;
    }

   
}
    


